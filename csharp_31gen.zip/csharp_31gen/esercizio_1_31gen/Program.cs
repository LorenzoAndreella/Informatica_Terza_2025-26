﻿using System;

internal class Program
{
    public static void Main(string[] args)
    {
        int n;
        double s = 0;

        Console.WriteLine("Inserisci il codice di transazione (numero di Armstrong): ");
        bool x = int.TryParse(Console.ReadLine(), out n);

        while (!x || n < 0)
        {
            Console.WriteLine("Inserisci un numero valido: ");
            x = int.TryParse(Console.ReadLine(), out n);
        }

        int temp = n;
        int lung = 0;

        if (temp == 0)
            lung = 1;
        else
        {
            while (temp > 0)            //lunghezza (sfrutto che temp è intero)
            {
                lung++;
                temp /= 10;
            }
        }

        temp = n;

       
        while (temp > 0)             //somma delle potenze
        {
            int cifra = temp % 10;
            s += Math.Pow(cifra, lung);
            temp /= 10;
        }

        if (s == n)
            Console.WriteLine($"Il numero {n} è valido! (numero di Armstrong)");
        else
            Console.WriteLine("Il numero non è valido");
    }
}