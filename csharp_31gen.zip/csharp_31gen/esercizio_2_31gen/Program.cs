﻿using System;

internal class NumeriAmicali
{
    public static void Main(string[] args)
    {
      int n, n1, s=0, s1=0;
      Console.WriteLine("Scrivi il primo conto");
      bool x = int.TryParse(Console.ReadLine(),out n);
      while (!x || n < 0)
        {
            Console.WriteLine("Errore. Scrivi il primo conto");
            x = int.TryParse(Console.ReadLine(),out n);             //controllare che sia un numero
        }

      Console.WriteLine("Scrivi il secondo conto");
      x = int.TryParse(Console.ReadLine(),out n1);
      while (!x || n1 < 0)          //non numero o negativo
        {
            Console.WriteLine("Errore. Scrivi il secondo conto");
            x = int.TryParse(Console.ReadLine(),out n1);
        }
        for (int i=1; i<= n/2; i++)         //sommo i divsori 
        {
            if (n%i == 0)
            {
               s+=i; 
            }
        }

        for (int i=1; i<=n1/2; i++)
        {
            if (n1%i == 0)
            {
               s1+=i; 
            }
        }

        if((s == n1) && (s1 == n))              //se la somma dei divisori di un numero è uguale all'altro numero e viceversa sono amicali
        {
            Console.WriteLine("I due numeri sono amicali!");
        } else
        {
            Console.WriteLine("I due numeri non sono amicali");
        }
    }

}

        
