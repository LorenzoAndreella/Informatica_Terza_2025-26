﻿using System;
internal class SequenzaCollantz
{
    public static void Main(string[] args)
    {
      int n;
      Console.WriteLine("Inserisci un numero per la sequena di Collantz: ");
      bool x = int.TryParse(Console.ReadLine(), out n);
      while (!x || n<=0)                    //controllo che sia un numero valido
        {
            Console.WriteLine("Errore, scrivi un numero valido");
            x = int.TryParse(Console.ReadLine(), out n);
        }
        Console.WriteLine("La sequenza di Collantz:");
        while (n != 1)              //sequenza di collantz fino a che N non diventa 1
        {
            if (n % 2 == 0)         //se è pari fa diviso 2
            {
                n = n/2;
                
            } else                  //se è dispari fa per n*3 +1
            {
                n = (n*3)+1;
            }
            Console.WriteLine(n);
        }

    }

}

        
