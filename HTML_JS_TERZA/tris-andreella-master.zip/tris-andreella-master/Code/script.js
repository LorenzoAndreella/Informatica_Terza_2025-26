//tutti gli array
let mat = [];
    mat[0] = ["V","V","V"];
    mat[1] = ["V","V","V"];
    mat[2] = ["V","V","V"];
let giocatore =true;
function tris(g) {

    g = parseInt(g);
    let puls = document.getElementById(g);
    puls.disabled = true;

    if (giocatore == true) {
            puls.value = "O";
            giocatore = false;
        } else {
            puls.value = "X";
            giocatore = true;
        }

    if (g<3) {
        mat[0][g] = puls.value;   
    } else if (g<6) {
        mat[1][g-3] = puls.value;
    } else {
        mat[2][g-6] = puls.value;
    }

   let par = document.createElement('p');
   let mes = controllo(g);
   par.innerText = mes;
   let tab = document.getElementById('tabel');
   tab.appendChild(par);
}

function controllo(g) {
    let gioc;

    if (giocatore == true) {
        gioc = "X";
    } else {
        gioc = "O";
    }

    let rig = Math .floor((g/3));
    let col = parseInt(g-rig*3);

    
    if(mat[rig][0] == gioc && mat[rig][1] == gioc && mat[rig][2] == gioc){
        mess = "Hai Vinto " + gioc;
        return mess;
    } 
    
    if(mat[0][col] == gioc && mat[1][col] == gioc && mat[2][col] == gioc){
        mess = "Hai Vinto " + gioc;
        return mess;
    }

    if(mat[0][0] == gioc && mat[1][1] == gioc && mat[2][2] == gioc){
        mess = "Hai Vinto " + gioc;
        return mess;
    }

    if(mat[0][2] == gioc && mat[1][1] == gioc && mat[2][0] == gioc){
        mess = "Hai Vinto " + gioc;
        return mess;
    }

    mess = "";
    return mess;
}