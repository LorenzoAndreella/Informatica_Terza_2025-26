function calcolo() {
    
    let formm = document.getElementById('formm');
    formm.innerHTML = "";
    let tab = document.createElement('table');
    let c = 0;
    let matr = [];
    let somme = [];
    let par = document.createElement('p');
    
    for (let i=0; i<8; i++) {
        let row = document.createElement('tr');
        matr[i] = [];
        let somma =0;
        for (let j=0; j<8; j++) {
            c++;
            let cell = document.createElement('td');
            cell.id = c;
            matr[i][j] = Math.floor(Math.random() * 2);
            cell.innerText = matr[i][j];
            row.appendChild(cell);
            somma += matr[i][j];
        }
        tab.appendChild(row);
        somme.push(somma);
    }
    formm.appendChild(tab);
    formm.appendChild(par);
    let risultato = controllo(matr, somme);

    if (risultato == true) {
        par.innerText = "Sistema stabilizzato";
    } else {
        par.innerText = "Sistema non stabilizzato";
    }
}
function controllo(matr, somme) {
    for (let i=somme.length-1; i>0; i--) {
        if(somme[i] !== somme[i-1]){
            return false;
        }
    }
    return true;
}