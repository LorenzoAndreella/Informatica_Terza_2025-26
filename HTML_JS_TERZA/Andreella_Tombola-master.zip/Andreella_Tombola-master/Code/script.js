let vincita = 1;

function inizio() {
    document.getElementById('avvio').disabled = true;

    let numeri = [];
    let tombola = [];

    for (let i = 1; i <= 90; i++) {
        numeri.push(i);
        tombola.push(i);
    }

    let mat = generaCartelle(tombola);
    let tabelle = creaTabelleHTML(mat);
    creaTabellone(tabelle);
    creaPulsanteGioca(numeri, mat);
}

function generaCartelle(tombola) {
    let mat = [];

    for (let i = 0; i < 6; i++) {
        mat[i] = [];
        for (let j = 0; j < 3; j++) {
            mat[i][j] = [];
            for (let k = 0; k < 5; k++) {
                let indice = Math.floor(Math.random() * tombola.length);
                mat[i][j][k] = tombola[indice];
                tombola.splice(indice, 1);
            }
        }
    }
    return mat;
}

function creaTabelleHTML(mat) {
    let tabelle = [];

    for (let i = 0; i < 6; i++) {
        let table = document.createElement('table');
        table.id = "tabella" + i;

        for (let j = 0; j < 3; j++) {
            let riga = document.createElement('tr');
            riga.id = "riga" + i + j;
            riga.dataset.vinta = "0";
            riga.dataset.ok = "0";

            for (let k = 0; k < 5; k++) {
                let cella = document.createElement('td');
                cella.textContent = mat[i][j][k];
                cella.id = "cella" + mat[i][j][k];
                riga.appendChild(cella);
            }
            table.appendChild(riga);
        }
        tabelle.push(table);
    }
    return tabelle;
}

function creaTabellone(tabelle) {
    let tabellone = document.createElement('table');
    let c = 0;

    for (let i = 0; i < 3; i++) {
        let riga = document.createElement('tr');
        for (let j = 0; j < 2; j++) {
            let cella = document.createElement('td');
            cella.appendChild(tabelle[c]);
            riga.appendChild(cella);
            c++;
        }
        tabellone.appendChild(riga);
    }

    document.getElementById('tabellaa').appendChild(tabellone);
}

function creaPulsanteGioca(numeri, mat) {
    let gioca = document.createElement('button');
    gioca.id = "gioca";
    gioca.textContent = "GENERA NUMERO CASUALE";
    document.getElementById('tabellaa').appendChild(gioca);

    gioca.onclick = () => generaCasuale(numeri, mat);
        
}

function generaCasuale(numeri, mat) {
    document.getElementById('numerocasuale').innerHTML = "";

    let numIndice = Math.floor(Math.random() * numeri.length);
    let numeroCella = numeri[numIndice];
    numeri.splice(numIndice, 1);

    document.getElementById('numerocasuale').innerHTML = "Numero: " + numeroCella;

    let numeroAttuale = document.getElementById('cella' + numeroCella);
    numeroAttuale.style.backgroundColor = "rgb(92, 255, 47)";
    numeroAttuale.dataset.trovato = "1";

    let tab = -1;
    let rig = -1;

    for (let i = 0; i < 6; i++) {
        for (let j = 0; j < 3; j++) {
            for (let k = 0; k < 5; k++) {
                if (mat[i][j][k] === numeroCella) {
                    tab = i;
                    rig = j;
                }
            }
        }
    }

    controllaVinciteRiga(tab, rig, mat);
    controllaTombola(tab, mat);
}

function controllaVinciteRiga(tab, rig, mat) {
    let rigaHTML = document.getElementById("riga" + tab + rig);
    let trovati = 0;

    for (let i = 0; i < 5; i++) {
        let cel = document.getElementById('cella' + mat[tab][rig][i]);
        if (cel.dataset.trovato === "1") {
            trovati++;
        }
    }

    if (trovati === 5) {
        rigaHTML.dataset.ok = "1";
    }

    if (trovati > vincita && rigaHTML.dataset.vinta === "0") {
        let nomi = ["", "", "Ambo", "Terna", "Quaterna", "Cinquina"];

        document.getElementById('vincite').innerHTML = nomi[trovati] + " appena vinta!";
        document.getElementById('vincitori').innerHTML += "<br>" + nomi[trovati] + " vinta nella cartella " + numeroCartella(tab);

        vincita = trovati;
        rigaHTML.dataset.vinta = "1";

        coloraVincita(tab, rig, mat, trovati);
    }
}

function controllaTombola(tab, mat) {
    let tomb = 0;

    for (let i = 0; i < 3; i++) {
        let r = document.getElementById("riga" + tab + i);
        if (r.dataset.ok === "1") {
            tomb++;
        }
    }

    if (tomb === 3) {
        document.getElementById('vincite').innerHTML = "Tombola appena vinta!";
        document.getElementById('vincitori').innerHTML += "<br>Tombola vinta nella cartella " + numeroCartella(tab);

        coloraTombola(tab, mat);
        document.getElementById('gioca').disabled = true;
    }
}

function numeroCartella(tab) {
    let ordine = [1, 4, 2, 5, 3, 6];
    return ordine[tab];
}

function coloraVincita(tab, rig, mat, tipo) {
    let colori = ["", "", "deepskyblue", "orange", "violet", "gold"];

    for (let i = 0; i < 5; i++) {
        let cella = document.getElementById('cella' + mat[tab][rig][i]);
        if (cella.dataset.trovato === "1") {
            cella.style.backgroundColor = colori[tipo];
        }
    }
}

function coloraTombola(tab, mat) {
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 5; j++) {
            let cella = document.getElementById('cella' + mat[tab][i][j]);
            cella.style.backgroundColor = "red";
            cella.style.color = "white";
        }
    }
}
