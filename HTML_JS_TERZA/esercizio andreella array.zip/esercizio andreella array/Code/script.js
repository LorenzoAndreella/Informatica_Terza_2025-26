let vettore = [];
let i=0;
function array10(a) {
    if (isNaN(a)) {
        document.getElementById("par").innerText = "Errore";
        for (let j=0; j<10;j++) {
            vettore[j] = "";
            i=0;
        }
        return;
    }
    if (i<10) {
        let n = parseInt(a);
        vettore[i] = n;
        document.getElementById("num").value = "";
    } else {
        let risposta = "Vettore :" + vettore.toString();
        console.log(vettore.toString);
        document.getElementById("par").innerHTML = risposta;
    }
    i++;
}