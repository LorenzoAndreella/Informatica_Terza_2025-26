function conversione(num) {
    let n = parseInt(num);
    let str = "";
    if (isNaN(n) || n<0 || n>9999) {
        str = "Errore, inserisci un numero valido";
        document.getElementById("risp").innerText = str;
    } else {
        let binario = [];
        max = n;
        let bit =0;
        for (i=0; n>0; i++) {
            binario[i] = n%2;
            n=Math.floor(n/2);
            bit++;
        }  
        for (let j=bit-1; j>=0; j--) { //riordina
            str += binario[j];
        }
        if (bit==0){
            document.getElementById("risp").innerText = "Numero in binario: 0";
        } else {
            document.getElementById("risp").innerText = "Numero in binario: " + str;
        }
    } 
}