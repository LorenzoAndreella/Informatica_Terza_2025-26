function calcolo() {
    let mat = [
        [220, 310],
        [230, 280],
    ];
    
    for (let i=0; i<mat.length; i++) {
        for (let j=0; j<mat[i].length; j++) {
            if (i == 0) {
                mat[i][j] = mat[i][j]/100*120;
                document.getElementById(j).innerHTML = mat[i][j]
            } else {
                mat[i][j] = mat[i][j]/100*105;
                document.getElementById(j+2).innerHTML = mat[i][j]
            }
            
        }
    }
    
}