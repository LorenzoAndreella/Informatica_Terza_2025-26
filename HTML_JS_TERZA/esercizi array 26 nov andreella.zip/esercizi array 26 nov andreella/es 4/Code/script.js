function controllo() {
    let formc = document.getElementById("formarray");
    let str = document.createElement("p");
    for (let i=0; i<10; i++) {
        let dato = Number(document.getElementById("n"+i).value);
    
        if (isNaN(dato) || dato<1 || dato>10) {
            str.textContent = "Errore insersci numeri validi";
            formc.appendChild(str);
            return;
        }
    }
    calcolo(str, formc);
    }

function calcolo(str, formc){
    let max = 0;
    let min = 10;
    let media = 0;
    let voti = [];
    let ins =0;
    max = massimo(str, formc, voti, max);
    min = minimo(str, formc, voti, min);
    media = median(str, formc, voti, media)
    ins = insuf(str, formc, voti, ins);
    str.textContent = "Media: " + media + " Insufficienze: " + ins + " Voto max: " + max + " Voto min: " +min;
    formc.appendChild(str);
}

function massimo(str, formc, voti, max) {    
     for(let i=0; i<10; i++) {
        voti[i] = Number(document.getElementById("n"+i).value);
        if (voti[i] > max) {
            max = voti[i];
        }
    }
    return max;
}

function minimo(str, formc, voti, min) {
    for(let i=0; i<10; i++) {    
        voti[i] = Number(document.getElementById("n"+i).value);
        if (voti[i] < min) {
            min = voti[i];
        }
    }
    return min;
}

function median(str, formc, voti, media) {
    for(let i=0; i<10; i++) {   
        media += voti[i];
    }
    media = media/10;
    return media;
}

function insuf(str, formc, voti, ins) {
     for(let i=0; i<10; i++) {
        voti[i] = Number(document.getElementById("n"+i).value);
        if (voti[i] < 6) {
            ins++;
        }
    }
    return ins;
}

