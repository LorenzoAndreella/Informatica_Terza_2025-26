function controllo(a, b) {
    let formc = document.getElementById('formarray');
    leg = parseInt(b);
    q = parseInt(a);
    if (isNaN(q) || q <0 || isNaN(leg) || leg < 0) {
        let p = document.createElement("p");
        formc.appendChild(p);
        p.textContent = "Errore inserisci un valore valido";
        document.getElementById("q").value = "";
        document.getElementById("q").focus();
        document.getElementById("leg").value = "";
        return;
    }
    let input;
    document.getElementById("q").disabled = true;
    document.getElementById("invia").disabled = true;
    document.getElementById("leg").disabled = true;

    for (let i=0; i<q; i++) {
        input = document.createElement("input");
        input.id = "inp" + i;
        input.placeholder = "Inserisci numero";
        input.type = "number";
        input.min = "1";
        formc.appendChild(input);
        formc.appendChild(document.createElement("br"));
    }
    formc.appendChild(document.createElement("br"));
    let bottone = document.createElement("button");
    bottone.id = "arr";
    bottone.type = "button";
    bottone.textContent = "INVIA"
    bottone.onclick = () => conta(q, leg, formc);
    formc.appendChild(bottone);
}

function conta(q, leg, formc) {
    let contatore = [];
    let k = 0;
    let str = document.createElement("p");
    for (let i=0; i<q; i++) {
        let num = parseInt(document.getElementById("inp" + i).value);
        contatore.push(parseInt(num));
        if (num == leg) {
            k++;
        }
        }
    str.textContent = "Ci sono esattamente " + k + " " + leg + " nella sequenza";
        formc.appendChild(str);
        console.log(contatore.join(","))
    }
