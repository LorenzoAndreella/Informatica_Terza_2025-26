function controllo(a, b) {
    let formc = document.getElementById('formarray');
    q = parseInt(a);
    leg = b;
    if (isNaN(q) || q <0) {
        let p = document.createElement("p");
        formc.appendChild(p);
        p.textContent = "Errore inserisci un valore valido";
        document.getElementById("q").value = "";
        document.getElementById("q").focus();
        document.getElementById("leg").value = "";
        return;
    }
    let input;
    document.getElementById("q").disabled = true;
    document.getElementById("invia").disabled = true;
    document.getElementById("leg").disabled = true;

    for (let i=0; i<q; i++) {
        input = document.createElement("input");
        input.id = "inp" + i;
        input.placeholder = "Inserisci nome alunno";
        input.type = "text";
        formc.appendChild(input);
        formc.appendChild(document.createElement("br"));
    }
    formc.appendChild(document.createElement("br"));
    let bottone = document.createElement("button");
    bottone.id = "arr";
    bottone.type = "button";
    bottone.textContent = "INVIA"
    bottone.onclick = () => conta(q, leg, formc);
    formc.appendChild(bottone);
}

function conta(q, leg, formc) {
    let classe = [];
    let str = document.createElement("p");
    for (let i=0; i<q; i++) {
        let studente = document.getElementById("inp" + i);
        classe.push(studente.value);
        }
    if (classe.includes(leg) == true) {
        str.textContent = leg + " è presente";
        formc.appendChild(str);
    } else {
        str.textContent = leg + " è assente";
        formc.appendChild(str);
    }
        console.log(classe.join(","))
    }
