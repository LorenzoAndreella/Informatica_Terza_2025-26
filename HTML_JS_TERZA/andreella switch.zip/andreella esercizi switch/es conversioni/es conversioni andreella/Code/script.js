function conversioni() {

    let b = document.getElementById("base").value;
    const n = parseInt(document.getElementById("numero").value);
    let soluzione;
    
    switch (b) {
        case "1":
            soluzione = "Il numero convertito è: " + parseInt(n,2);
         break;
        
         case "2":
            soluzione = "Il numero convertito è: " + n.toString(2);
        break;
         case "3": 
            soluzione = "Il numero convertito è: " + n.toString(16).toUpperCase();
        break;
        default: 
        soluzione = "errore";
    }

   document.getElementById("risposta").innerHTML = soluzione;
}