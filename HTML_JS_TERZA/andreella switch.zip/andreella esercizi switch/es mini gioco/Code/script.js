function indovina() {
    let a = parseInt(document.getElementById("azione").value);
    let b = document.getElementById("nome").value
    let soluzione;

    switch (b) {
        case "libro": 
            soluzione = "Corretto hai vinto!";
        break;
        default: 
            switch (a) {
            case 1:
                soluzione = "Colore bianco/crema"
                break;
            case 2:
                soluzione = "Liscio o leggermente ruvido, tanti elementi sottili";
                break;
            case 3:
                soluzione = "Profumo di inchiostro";
                break;
            case 4: 
                soluzione = "La soluzione era libro";
                break;
                default: soluzione = "Errore scrivi in minuscolo e numeri validi";
        }
    }

    document.getElementById("risposta").innerHTML = soluzione;
}
