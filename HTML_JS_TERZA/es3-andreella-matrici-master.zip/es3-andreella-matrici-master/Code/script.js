
function tabe() {
let mat = [];
let formm = document.getElementById('formm');
let tab = document.createElement('table');
let c=0;
document.getElementById('bottone').disabled = true;
    for (let i=0; i<10; i++){
        let rig = document.createElement('tr');
        mat[i] = [];
        for (let j=0; j<10; j++){
            c++;
            mat[i][j] = (i+1)*(j+1);
            let cell = document.createElement('td');
            let ins = document.createElement('input');
            ins.type = "number";
            ins.id = "cell"+c;
            cell.appendChild(ins);
            rig.appendChild(cell);
        }
        tab.appendChild(rig);
    }
    
    formm.appendChild(tab);
    bot = document.createElement('button');
    bot.type = 'button';
    bot.innerText = "INVIA";
    formm.appendChild(bot);
    bot.onclick = () => controllo(tab, mat, formm);
}

function controllo(tab, mat, formm) {
    let contr = false;
    let risp = document.createElement('p');
    let h=0;
    for (let i=0; i<10; i++){
        for (let j=0; j<10; j++){
            h++;
            if (parseInt(document.getElementById("cell"+h).value) !== mat[i][j]){
                contr = true;
            }
        }   
    }

    if (contr == true) {
        risp.innerText = "Hai sbagliato la tabella riprova!";
    } else {
        risp.innerText = "Tutto corretto!";
    }

    formm.appendChild(risp);

}