function costo() {
   let tempo = parseInt(document.getElementById("min").value);
   let tipologia = document.getElementById("tipo").value;
   let soluzione;
   let costo;

   if ((isNaN(tempo) || (tempo<1 || tempo>3000)) || (tipologia !== "coperto" && tipologia !=="aperto")) {
        soluzione = "Inserisci dei valori validi";
   } else if (tempo < 46) {
    soluzione = "Parcheggio gratis"; }
    else {
        let ore = parseInt(tempo/60);
        let min = parseInt((tempo - 60*ore)/15);
        if (ore==0) {
            ore = 1;
            min = 0;
        } 
        
        switch (tipologia) {
            case "coperto":
            if (ore>4) {
            costo = 12 + 2*(ore-4);
            costo = costo + min*0.5;
            soluzione = "Devi pagare: " + costo + " euro";
        } else {
            costo = 3*ore;
            costo = costo + min*0.75;
            soluzione = "Devi pagare: " + costo + " euro";
        } break;
            case "aperto":
            if (ore>4) {
            costo = 8 + (ore-4);
            costo = costo + min*0.5;
            soluzione = "Devi pagare: " + costo + " euro";
        } else {
            costo = 2*ore;
            costo = costo + min*0.5;
            soluzione = "Devi pagare: " + costo + " euro";
        } break;
        default: soluzione = "Inserisci valori validi";
        
    }}
    document.getElementById("risposta").innerText = soluzione;
   } 