function abbonamento() {
    let mf = document.getElementById("s").value;
    let fo = document.getElementById("f").value;
    let me= parseInt(document.getElementById("mesi").value);
    let p=0;
    let soluzione;
    if (me<1 || me>100) {
        soluzione = "Inserisci dei valori validi";
    }
    else {
    switch (mf) {
        case "1":
            switch (fo) {
                case "1":
                    if (me > 6) {
                        p = 10*me/100*75;
                        soluzione = "Devi pagare 10 euro al mese e hai diritto al 25% di sconto: " + p + " euro";
                    } else if(me > 3) {
                        p = 10*me/100*85;
                        soluzione = "Devi pagare 10 euro al mese e hai diritto al 15% di sconto: " + p + " euro";
                    } else {
                        p = 10*me;
                        soluzione = "Devi pagare 10 euro al mese: " + p + " euro";
                    }
                break;
                case "2":
                    if (me > 6) {
                        p = 15*me/100*75;
                        soluzione = "Devi pagare 15 euro al mese e hai diritto al 25% di sconto: " + p + " euro";
                    } else if(me > 3) {
                        p = 15*me/100*85;
                        soluzione = "Devi pagare 15 euro al mese e hai diritto al 15% di sconto: " + p + " euro";
                    } else {
                        p = 15*me;
                        soluzione = "Devi pagare 15 euro al mese: " + p + " euro";
                    }
                break;
                default:
                    soluzione = "Inserisci dei valori validi";
                } break;
        case "2": 
                switch (fo) {
                 case "1":
                    if (me > 6) {
                        p = 7*me/100*75;
                        soluzione = "Devi pagare 7 euro al mese e hai diritto al 25% di sconto: " + p + " euro";
                    } else if(me > 3) {
                        p = 7*me/100*85;
                        soluzione = "Devi pagare 7 euro al mese e hai diritto al 15% di sconto: " + p + " euro";
                    } else {
                        p = 7*me;
                        soluzione = "Devi pagare 7 euro al mese: " + p + " euro";
                    }
                break;
                 case "2":
                    if (me > 6) {
                        p = 11*me/100*75;
                        soluzione = "Devi pagare 11 euro al mese e hai diritto al 25% di sconto: " + p + " euro";
                    } else if(me > 3) {
                        p = 11*me/100*85;
                        soluzione = "Devi pagare 11 euro al mese e hai diritto al 15% di sconto: " + p + " euro";
                    } else {
                        p = 11*me;
                        soluzione = "Devi pagare 11 euro al mese: " + p + " euro";
                    }
                break;
                default:
                    soluzione = "Inserisci dei valori validi";
                } break;
        default:    soluzione = "Inserisci dei valori validi";
     }
    } 
    document.getElementById("risposta").innerText = soluzione;
}

