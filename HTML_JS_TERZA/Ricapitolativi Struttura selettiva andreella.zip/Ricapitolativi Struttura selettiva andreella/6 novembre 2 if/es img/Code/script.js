function immagine() {
let s=document.getElementById("scelta").value;
let t=document.querySelector('input[name="colore"]:checked');
let soluzione="0";
if (!t) {
    soluzione =  "Seleziona un'immagine e un tema (colori o bianco e nero).";
        document.getElementById("err").innerText = soluzione;
    } else {
    switch(s) {
        case "0":
            if(t.value=="1") {
               soluzione = "montagna.jpg";
               document.getElementById("foto").src = `Img/${soluzione}`;
               } else if (t.value=="2") {
                soluzione = "montagna-bn.jpg";
                document.getElementById("foto").src = `Img/${soluzione}`;
               } else {
                soluzione = "Seleziona una scelta";
                document.getElementById("err").innerText = soluzione;
               }
            break;

        case "1":
            if(t.value=="1") {
               soluzione = "mare.jpg";
               document.getElementById("foto").src = `Img/${soluzione}`;
               } else if (t.value=="2") {
                soluzione = "mare-bn.jpg";
                document.getElementById("foto").src = `Img/${soluzione}`;
               } else {
                soluzione = "Seleziona una scelta";
                document.getElementById("err").innerText = soluzione;
               }
            break;

        case "2":
            if(t.value=="1") {
               soluzione = "città.jpg";
               document.getElementById("foto").src = `Img/${soluzione}`;
               } else if (t.value=="2") {
                soluzione = "città-bn.jpg";
                document.getElementById("foto").src = `Img/${soluzione}`;
               } else {
                soluzione = "Seleziona una scelta";
                document.getElementById("err").innerText = soluzione;
               }
            break;
        default:soluzione = "Seleziona una scelta";
                document.getElementById("err").innerText = soluzione;

    } }
   
}