function ristorante() {
let s=document.getElementById("scelta").value;
let t=document.querySelector('input[name="f"]:checked').value;
let soluzione="0";

    switch(s) {
        case "0":
            if(t=="0") {
               soluzione = "Hai messo 0 stelle e una valutazione negativa";
               document.getElementById("voto").innerHTML = soluzione;
               } else if (t=="1") {
                soluzione = soluzione = "Hai messo 0 stelle e una valutazione positiva";;
                document.getElementById("voto").innerHTML = soluzione;
               } else {
                soluzione = "Seleziona una scelta";
                document.getElementById("voto").innerHTML = soluzione;
               }
            break;

        case "1":
            if(t=="0") {
               soluzione = "Hai messo 1 stella e una valutazione negativa";
               document.getElementById("voto").innerHTML = soluzione;
               } else if (t=="1") {
                soluzione = soluzione = "Hai messo 1 stella e una valutazione positiva";;
                document.getElementById("voto").innerHTML = soluzione;
               } else {
                soluzione = "Seleziona una scelta";
                document.getElementById("voto").innerHTML = soluzione;
               }
            break;

        case "2":
            if(t=="0") {
               soluzione = "Hai messo 2 stelle e una valutazione negativa";
               document.getElementById("voto").innerHTML = soluzione;
               } else if (t=="1") {
                soluzione = soluzione = "Hai messo 2 stelle e una valutazione positiva";;
                document.getElementById("voto").innerHTML = soluzione;
               } else {
                soluzione = "Seleziona una scelta";
                document.getElementById("voto").innerHTML = soluzione;
               }
            break;

        case "3":
            if(t=="0") {
               soluzione = "Hai messo 3 stelle e una valutazione negativa";
               document.getElementById("voto").innerHTML = soluzione;
               } else if (t=="1") {
                soluzione = soluzione = "Hai messo 3 stelle e una valutazione positiva";;
                document.getElementById("voto").innerHTML = soluzione;
               } else {
                soluzione = "Seleziona una scelta";
                document.getElementById("voto").innerHTML = soluzione;
               }
            break;
        
        case "4":
            if(t=="0") {
               soluzione = "Hai messo 4 stelle e una valutazione negativa";
               document.getElementById("voto").innerHTML = soluzione;
               } else if (t=="1") {
                soluzione = soluzione = "Hai messo 4 stelle e una valutazione positiva";;
                document.getElementById("voto").innerHTML = soluzione;
               } else {
                soluzione = "Seleziona una scelta";
                document.getElementById("voto").innerHTML = soluzione;
               }
            break;

        case "5":
            if(t=="0") {
               soluzione = "Hai messo 5 stelle e una valutazione negativa";
               document.getElementById("voto").innerHTML = soluzione;
               } else if (t=="1") {
                soluzione = soluzione = "Hai messo 5 stelle e una valutazione positiva";;
                document.getElementById("voto").innerHTML = soluzione;
               } else {
                soluzione = "Seleziona una scelta";
                document.getElementById("voto").innerHTML = soluzione;
               }
            break;
        default:soluzione = "Seleziona una scelta";
                document.getElementById("voto").innerHTML = soluzione;
                break;
    }
   
}