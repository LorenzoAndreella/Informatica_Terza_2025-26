function hotel() {
    let stagione = document.getElementById("s").value;
    let stanza = document.getElementById("st").value;
    let g = parseInt(document.getElementById("giorni").value);
    let soluzione = "";
    let p = 0;
    let sconto=0;
    if (g<1 || g>100 || isNaN(g)) {
        soluzione = "Inserisci dei valori validi";
        document.getElementById("risposta").innerText = soluzione;
        return 0;
    } else if (g<3) {
        sconto = 1;
    } else if (g<8) {
        sconto = 0.75;
    } else {
        sconto = 0.65;
    }
    switch (stagione) {
        case "bs":
            switch (stanza) {
                case "b":
                    p = 15*g*sconto +5;
                    soluzione = "Tariffa 15 euro al giorno: " + p + " euro";
                break;
                case "m":
                    p = 30*g*sconto +5;
                    soluzione = "Tariffa 30 euro al giorno: " + p + " euro";
                break;
                case "a":
                    p = 45*g*sconto +5;
                    soluzione = "Tariffa 45 euro al giorno: " + p + " euro";
                break;
                default: soluzione = "Inserisci dei valori validi";
            } break;
        case "ms":
            switch (stanza) {
                case "b":
                    p = 20*g*sconto +5;
                    soluzione = "Tariffa 20 euro al giorno: " + p + " euro";
                break;
                case "m":
                    p = 35*g*sconto +5;
                    soluzione = "Tariffa 35 euro al giorno: " + p + " euro";
                break;
                case "a":
                    p = 50*g*sconto +5;
                    soluzione = "Tariffa 50 euro al giorno: " + p + " euro";
                break;
                default: soluzione = "Inserisci dei valori validi";
            } break;
        case "as":
            switch (stanza) {
                case "b":
                    p = 25*g*sconto +5 ;
                    soluzione = "Tariffa 25 euro al giorno: " + p + " euro";
                break;
                case "m":
                    p = 40*g*sconto +5;
                    soluzione = "Tariffa 40 euro al giorno: " + p + " euro";
                break;
                case "a":
                    p = 55*g*sconto +5;
                    soluzione = "Tariffa 55 euro al giorno: " + p + " euro";
                break;
                default: soluzione = "Inserisci dei valori validi";
            } break;
        default: soluzione = "Inserisci dei valori validi";
    }

    document.getElementById("risposta").innerText = soluzione;
}