function imposta() {
    let s = parseFloat(document.getElementById("soldi").value);
    let soluzione =0;
    if (s<0 || s >999999999) {
        soluzione="Inserisci un valore valido"
        document.getElementById("risposta").innerText = soluzione;
    } else if (s<=15000) {
        if (s<=3000) {
            soluzione="Non hai imposte dovute"
            document.getElementById("risposta").innerText = soluzione;
        }
        s = (s-3000) * 23/100;
        soluzione="Devi pagare un'aliquota pari al 23% ovvero: " + s + " euro";
        document.getElementById("risposta").innerText = soluzione;
    } else if (s<=28000) {
        s = 3450 + s * 27/100;
        soluzione="Devi pagare un'aliquota pari al 23% e 3450 euro ovvero: " + s + " euro";
        document.getElementById("risposta").innerText = soluzione;
    } else if (s<=55000) {
        s = 6960 + s * 38/100;
        soluzione="Devi pagare un'aliquota pari al 38% e 6960 euro ovvero: " + s + " euro";
        document.getElementById("risposta").innerText = soluzione;
    } else if (s<=75000) {
        s = 17220 + s * 41/100;
        soluzione="Devi pagare un'aliquota pari al 41% e 17220 euro ovvero: " + s + " euro";
        document.getElementById("risposta").innerText = soluzione;
    } else {
        s = 25420 + s * 43/100;
        soluzione="Devi pagare un'aliquota pari al 43% e 25420 euro ovvero: " + s + " euro";
        document.getElementById("risposta").innerText = soluzione;
    }
}