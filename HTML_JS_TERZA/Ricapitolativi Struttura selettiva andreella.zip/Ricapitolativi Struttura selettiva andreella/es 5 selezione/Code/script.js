function costo() {
    let m = document.getElementById("mezzo").value;
    let t = document.getElementById("tipo").value;
    let min = parseInt(document.getElementById("min").value);
    let soluzione;
    let costo;
    if ((isNaN(min) || (min<1 || min>3000)) || (t !== "coperto" && t !=="scoperto") || (m !== "auto" && m !=="moto")) {
        soluzione = "Inserisci dei valori validi";
    } else {
    switch (m) {
        case "moto": 
            switch (t) {
                case "coperto":
                    if (min<60) {
                    costo = min*0.013;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } else if (min <121) {
                    costo = 60*0.013 + (min-60)*0.013*70/100;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } else {
                    costo = 60*0.013 + 60*0.013*70/100 + (min-120)*0.013*0.5;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } break;
                case "scoperto":
                    if (min<60) {
                    costo = min*0.010;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } else if (min <121) {
                    costo = 60*0.010 + (min-60)*0.010*70/100;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } else {
                    costo = 60*0.010 + 60*0.010*70/100 + (min-120)*0.010*0.5;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } break;
                default : soluzione = "Inserisci dei valori validi";
            } break;
        case "auto": 
            switch (t) {
                case "coperto":
                    if (min<60) {
                    costo = min*0.025;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } else if (min <121) {
                    costo = 60*0.025 + (min-60)*0.025*70/100;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } else {
                    costo = 60*0.025 + 60*0.025*70/100 + (min-120)*0.025*0.5;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } break;
                case "scoperto":
                    if (min<60) {
                    costo = min*0.015;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } else if (min <121) {
                    costo = 60*0.015 + (min-60)*0.015*70/100;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } else {
                    costo = 60*0.015 + 60*0.015*70/100 + (min-120)*0.015*0.5;
                    soluzione = "Devi pagare: " + costo + " euro";
                    } break;
                default : soluzione = "Inserisci dei valori validi";
            } break;
        default: soluzione = "Inserisci dei valori validi";
   }} document.getElementById("risposta").innerText = soluzione;
}
