function scacchiera(a) {
    let n = parseInt(a);
    if (isNaN(n) || n<1 || n>10) {
        document.getElementById("par").innerText = "Errore inserisci un valore da 1 a 10 compresi";
        document.getElementById("n").value = "";
        document.getElementById("n").focus;
        str ="";
        document.getElementById("risp").innerHTML = str;
        document.getElementById("n").focus();
    } else {
        let str = tabella(n);
        document.getElementById("risp").innerHTML = str;
        }
}

function tabella(n) {
    let s = 0;
    let str = "<table>";
    for (let i = 1; i <= n; i++) {
        str += "<tr>";
        for (let j = 1; j <= n; j++) {
            let n1=i*j;
            str += "<td> " +n1+ " </td>";
            s += n1;
        }
        str += "</tr>";
    }
    str += "</table>";
    document.getElementById("par").innerText = "La somma dei numeri nella tabella: " + s;
    return str;
}
