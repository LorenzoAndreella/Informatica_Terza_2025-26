function cifrario(a, b) {
    let n = parseInt(a);
    let s = b;
    let str;

    if (isNaN(n) || n < 0 || n > 999) {
        document.getElementById("par").innerText = "Errore: inserisci un numero valido (0-999)";
        document.getElementById("mes").value = "";
        document.getElementById("mes").focus();
        document.getElementById("c").value = "";
        return;
    }
    n = n % 26;
    for (let i = 0; i < s.length; i++) {
        let codice = s.charCodeAt(i);
        if (codice < 65 || (codice > 90 && codice < 97) || codice > 122) {
            document.getElementById("par").innerText = "Errore: inserisci solo lettere dell'alfabeto";
            document.getElementById("mes").value = "";
            document.getElementById("mes").focus();
            document.getElementById("c").value = "";
            return;
        }
    }

    str = cesare(n, s);
    document.getElementById("par").innerText = "Il messaggio crittografato: " + str;
}

function cesare(n, s) {
    let risultato = "";
    for (let i = 0; i < s.length; i++) {
        let codice = s.charCodeAt(i);
        let codiceBase;

        if (codice >= 65 && codice <= 90) {
            codiceBase = 65;
        } else if (codice >= 97 && codice <= 122) {
            codiceBase = 97;
        }

        let critt = ((codice - codiceBase + n) % 26) + codiceBase;
        risultato += String.fromCharCode(critt);
    }
    return risultato;
}
