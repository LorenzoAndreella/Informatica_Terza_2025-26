function stelle(a, b) {
    let n = parseInt(a);
    let f = parseInt(b);
    let str ="";
    if (isNaN(n) || n<0 || n>999 || isNaN(f) || f<1 || f>4) {
        document.getElementById("par").innerText = "Errore inserisci valori validi";
        document.getElementById("n").value = "";
        document.getElementById("n").focus();
        document.getElementById("f").value = "";
        str ="";
        document.getElementById("risp").innerHTML = str;
    } else {
        str = tabella(n,f);
        document.getElementById("risp").innerHTML = str;
        }
}

function tabella(n, f) {
    let str = "<table>";
    switch (f) {
        case 1: 
            for (let i=0; i<n; i++) {
                str += "<tr>"
                for (let j=0; j<n; j++) {
                    str += "<td>*</td>"
                }
                str += "</tr>";
            } break;
        case 2: 
            for (let i=0; i<n; i++) {
                str += "<tr>"
                for (let j=0; j<n; j++) {
                    if (j ==0 || j ==n-1 || i ==0 || i == n-1) 
                        str += "<td>*</td>";    
                    else 
                    str += "<td> </td>";
                } 
                str += "</tr>";
            }  break;
        case 3: 
            for (let i=0; i<n; i++) {
                str += "<tr>"
                for (let j=0; j<=i; j++) {   
                        str += "<td>*</td>";    
                } 
                str += "</tr>";
            } break;
        case 4: 
            let i;
            for (i=0; i<n; i++) {
                str += "<tr>"
                for (let j=0; j<=i; j++) {   
                        str += "<td>*</td>";    
                } 
            for (let k=i+1; k<n; k++) {   
                        str += "<td>+</td>";    
                }
                str += "</tr>"; 
            }break;    

    }
    str += "</table>";
    return str;
}
