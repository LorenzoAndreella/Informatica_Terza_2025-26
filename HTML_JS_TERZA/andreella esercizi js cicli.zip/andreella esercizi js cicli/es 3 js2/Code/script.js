function triangolo(a) {
    let n = parseInt(a);
    let str ="";
    if (isNaN(n) || n<0 || n>999) {
        document.getElementById("par").innerText = "Errore inserisci valori validi";
        document.getElementById("n").value = "";
        str ="";
        document.getElementById("risp").innerHTML = str;
    } else {
        str = tabella(n);
        document.getElementById("risp").innerHTML = str;
        }
}

function tabella(n) {
    let str = "<table>";
    let n1 = 0;
     for (let i=0; i<n; i++) {
                str += "<tr>"
                for (let j=0; j<=i; j++) {
                    n1 ++;
                    str += "<td> "+n1+"</td>"
                }
                str += "</tr>";
            }
    
    str += "</table>";
    return str;
}
