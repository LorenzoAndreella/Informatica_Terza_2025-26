function tabellacolorata(a, b) {
    let r = parseInt(a);
    let c = parseInt(b);
    if (isNaN(r) || isNaN(c) || r<0 || c <0 || r>200 || c>200) {
        document.getElementById("err").innerText = "Errore";
        document.getElementById("righe").value = "";
        document.getElementById("righe").focus();
        document.getElementById("col").value = "";
        str ="";
        document.getElementById("risp").innerHTML = str
    } else {
        let str = tabella(r, c);
        document.getElementById("risp").innerHTML = str;}
}

function tabella(r, c) {
    let str = "<table>";
    for (let i = 0; i < r; i++) {
        str += "<tr>";
        for (let j = 0; j < c; j++) {
            let rgb1 = Math.round(Math.random() * 255);
            let rgb2 = Math.round(Math.random() * 255);
            let rgb3 = Math.round(Math.random() * 255);

            str += `<td style="background-color: rgb(${rgb1}, ${rgb2}, ${rgb3});"></td>`;
        }
        str += "</tr>";
    }
    str += "</table>";
    return str;
}
