function tasse() {
    let r = parseInt(document.getElementById("re").value);
    let soluzione = 0;
    if (r<0 || r>999999999999){
            soluzione = "Inserisci un valore valido";
         } else if(r<15000){
            soluzione = "Hai una tassa del 10% e devi pagare " + 10*r/100 + " euro";
         } else if(r<=30000){
            soluzione = "Hai una tassa del 20% e devi pagare " + 20*r/100 + " euro";
         } else {
            soluzione = "Hai una tassa del 30% e devi pagare " + 30*r/100 + " euro";
         }
    
     document.getElementById("risposta").innerHTML = soluzione;
}

