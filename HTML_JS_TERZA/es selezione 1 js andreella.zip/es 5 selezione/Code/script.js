function voto() {
    let v = parseInt(document.getElementById("vot").value);
    let soluzione = 0;
    if (v<0 || v>100){
            soluzione = "Inserisci un valore valido";
         } else if(v<60){
            soluzione = "Male impegnati!: E";
         } else if(v<70){
            soluzione = "Bene, ma devi migliorare: D";
         } else if(v<80){
            soluzione = "Bene, ma puoi fare di meglio: C";
         } else if(v<90){
            soluzione = "Molto bene!: B";
         } else {
            soluzione = "Ottimo continua così: A";
         }
    
     document.getElementById("risposta").innerHTML = soluzione;
}

