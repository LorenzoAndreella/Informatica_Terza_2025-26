function calcolo() {
    let a = document.getElementById("c1").value;
    let b = document.getElementById("c2").value;
    let c = parseInt(document.getElementById("c3").value);
    let soluzione = 0;
    if(isNaN(c)) {
        soluzione="Il terzo carattere non corrisponde a una cifra";
    } else if((Math.abs((b.charCodeAt(0))-(a.charCodeAt(0))) == c)) {
        soluzione="La distanza tra i due caratteri iniziali in ASCII corrisponde alla terza cifra";
    } else {
        soluzione="La distanza tra i due caratteri iniziali in ASCII non corrisponde alla terza cifra";
    }
    
     document.getElementById("risposta").innerHTML = soluzione;
}

