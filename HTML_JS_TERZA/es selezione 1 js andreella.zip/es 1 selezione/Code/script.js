function analisi() {
    let s= document.getElementById("scelta").value;
    let a= parseInt(document.getElementById("n1").value);
    let b= parseInt(document.getElementById("n2").value);
    let soluzione=0;
    let somma = 0;
    switch(s) {
        case "1":
            if(b>0) {
                soluzione="B è positivo";
            } else if(b!==0){
                soluzione="B è negativo";
            } else {
                soluzione="B è nullo";
            }
            break;
        case "2":
            if(a==0) { 
                soluzione="A vale 0";
            }else if(a%2==0) {
                soluzione="A è pari";
            } else {
                soluzione="A è dispari";
            }
            break;
        case "3": {
            somma = a+b;
                soluzione = "La somma vale: " + somma;
            break;
        }
        case "4" :
            somma = Math.abs(a) + Math.abs(b);
            if(a==0 && b==0) {
                soluzione = "La somma massima: 0";
            } else if (a<=0 && b>=0){
                soluzione = "La somma massima si ottiene con -A e +B: " + somma;
            } else if(a>=0 && b<=0) {
                soluzione = "La somma massima si ottiene con +A e -B: " + somma;
            } else if (a>=0 && b>=0){
                soluzione = "La somma massima si ottiene con +A e +B: " + somma;
            } else { 
                soluzione = "La somma massima si ottiene con -A e -B: " + somma;
            }
            break;
        default: soluzione = "Scegli un'opzione";
    }
    document.getElementById("risposta").innerHTML = soluzione;
}