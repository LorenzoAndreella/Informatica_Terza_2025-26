function sconto() {
    let p = parseFloat(document.getElementById("prezzo").value);
    let soluzione = 0;
    if (p<0 || p>9999){
            soluzione = "Inserisci un valore valido";
         } else if(p<50){
            soluzione = "Non hai uno sconto e devi pagare " + p + " euro";
         } else if(p<=100){
            soluzione = "Hai uno sconto del 5% e devi pagare " + 95*p/100 + " euro";
         } else {
            soluzione = "Hai uno sconto del 10% e devi pagare " + 90*p/100 + " euro";
         }
    
     document.getElementById("risposta").innerHTML = soluzione;
}

