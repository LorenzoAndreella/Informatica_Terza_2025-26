function piatto() {
    let p = parseInt(document.getElementById("scelta").value);
    let soluzione = 0;
    switch (p) {
      case 1:
         soluzione="Pizza - $10";
      break;
      case 2:
         soluzione="Pasta - $8";
      break;
      case 3:
         soluzione="Insalata - $5";
      break;
      case 4:
         soluzione="Hamburger - $12";
      break;
      case 5:
         soluzione="Zuppa - $6";
      break;
      default: soluzione="Scegli un piatto";
      console.log(p);
      break;
    }
    
     document.getElementById("risposta").innerHTML = soluzione;
}

