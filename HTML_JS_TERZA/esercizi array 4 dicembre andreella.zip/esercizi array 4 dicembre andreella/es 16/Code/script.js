function controllo(l) {
    let lung = parseInt(l);
    let formm = document.getElementById('corpo');
    let risp = document.createElement('p');
   
    if (isNaN(lung) || lung<1 || lung >99) {
        risp.innerText = "Inserisci dei valori validi";
        formm.appendChild(risp);
        document.getElementById('lunghezza').value = "";
        return;
    }
    vett1(lung, formm, risp);
}

function vett1(lung, formm, risp) {
    let input;
        document.getElementById("lunghezza").disabled = true;
        document.getElementById("invia").disabled = true;
        formm.appendChild(document.createElement("br"));
        for (let i=0; i<lung; i++) {
            input = document.createElement("input");
            input.id = "inp" + i;
            input.placeholder = "Inserisci numero";
            input.type = "number";
            formm.appendChild(input);
            formm.appendChild(document.createElement("br"));
        }
    formm.appendChild(document.createElement("br"));
    let bottone = document.createElement("button");
    bottone.id = "arr";
    bottone.type = "button";
    bottone.textContent = "INVIA"
    bottone.onclick = () => conta(lung, formm ,risp);
    formm.appendChild(bottone);
}

function conta (lung, formm, risp) {
    let vettp = [];
    let vettd = [];
    for (let i=0; i< lung; i++) {
        let numero = parseInt(document.getElementById('inp'+i).value);
        if (numero%2 == 0) {
            vettp.push(numero);
        } else if (numero%2 == 1) {
            vettd.push(numero);
        } else {
            risp.innerText = "Inserisci dei valori validi";
            formm.appendChild(risp);
        return;
        }
    }
    risp.innerHTML = "I numeri pari sono: " + vettp.join(',') + "<br>";
    risp.innerHTML += "I numeri dispari sono: " + vettd.join(',') + "<br>";
    formm.appendChild(risp);
}