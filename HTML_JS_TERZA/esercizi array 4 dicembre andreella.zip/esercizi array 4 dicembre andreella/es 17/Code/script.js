function random() {
    let arr = [];
    for (let i=0; i<100; i++) {
        arr[i] = Math.floor(Math.random()*100) + 1;
    }
    freq(arr);
}

function freq(arr) {
    let risp = document.createElement('p')
    let corpo = document.getElementById('corpo');
    corpo.appendChild(risp);
    let arr2 = [];
    for (let i=1; i<11; i++) {
        arr2[i-1] = 0;
        for (let j=0; j<arr.length; j++) {
            if (arr[j] >= (i*10-10) && arr[j] < (i*10)) {
                arr2[i-1] += 1;
                console.log(arr2[i-1]);
            } else if (i == 10 && arr[j] == 100) {
                arr2[9] += 1;
            }
        }
        risp.innerHTML += "Ci sono nella sequenza " + arr2[i-1] + " numeri compresi tra " + (i*10-10) + " e " + (i*10) + " <br>";
    
    }
    risp.innerHTML += arr2.join(', ');
    return;
    }
