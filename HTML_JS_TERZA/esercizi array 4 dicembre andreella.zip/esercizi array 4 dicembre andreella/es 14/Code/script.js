function random() {
    let arr = [];
    for (let i=0; i<100; i++) {
        arr[i] = Math.floor(Math.random()*20) + 1;
    }
    freq(arr);
}
function freq(arr) {
    let risp = document.createElement('p')
    let corpo = document.getElementById('corpo');
    corpo.appendChild(risp);
    let arr2 = [];
    for (let i=1; i<21; i++) {
        arr2[i-1] = 0;
        for (num of arr) {
            if (num == i) {
                arr2[i-1] += 1;
                console.log(arr2[i-1]);
            }
        }
        risp.innerHTML += "<br> Ci sono " + arr2[i-1] + " " + i + " nella sequenza";
    }
    return;
    }
