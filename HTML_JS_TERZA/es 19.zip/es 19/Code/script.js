var kms = prompt("Inserisci i kilometri percorsi:", "");
var cs = prompt("Inserisci il codice tariffa:", "");

var km = parseInt(kms);
var c = parseInt(cs);
var soluzione;
var costo;

if((km<9999 && km > 0) && (c>=0 && c<=2)) {
    
if(c==0) {
     costo= 0.150*km;
     
}
    else if (c==1) {
         costo = 0.125*km;
            
    }
        else { 
          costo = 0.100*km;
            
         } 

    if(km <= 100) {
        costo = costo + km*0.01;
    } else {
        costo = costo + 0.01*100 + (km-100)*0.005;
    }
     soluzione = "Hai speso €" + costo;
} else {
    soluzione = "Per favore inserisci valori validi" ;
}
    document.getElementById("risposta").innerHTML = soluzione;

