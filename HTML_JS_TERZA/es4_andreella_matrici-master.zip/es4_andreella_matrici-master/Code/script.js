function calcolo() {
    let punt = [];
    punt[0] = [];
    punt[1] = [];
    punt[2] = [];
    punt[3] = [];
    let formm = document.getElementById('formm');
    let p = document.createElement('p');
    for (let i=0; i<16; i++){
        let punteg = parseInt(document.getElementById('a'+(i+1)).value);
        if(isNaN(punteg) || punteg <0) {
            p.innerText = "Inserisci un punteggio valido";
            document.getElementById('a'+(i+1)).value = "";
            formm.appendChild(p);
            return;
        }
        
        if (i<4) {
            punt[0].push(punteg);
        } else if (i<8) {
            punt[1].push(punteg);
        } else if (i<12) {
            punt[2].push(punteg);
        } else {
            punt[3].push(punteg);
        }
    }
    document.getElementById('invia').disabled = true;
    let som = [];
    som = sommapunt(punt, som)
    
    let max = 0;
    let gmax = -1;
    gmax = maxgioc(som, max, gmax);
    let maxp = 0;
    maxp = maxtot(punt, gmax, maxp);
    p.innerText = "Il punteggio massimo in una partita ottenuto dal giocatore con più punti complessivamente è: " + maxp;
    formm.appendChild(p);
}

function sommapunt(punt, som){

    for (let i=0; i<4; i++){
        let somma =0;
    for (let j=0; j<4; j++) {
        somma += punt[i][j];
    }
    som[i] = somma;
    }
    return som;
}

function maxgioc(som, max, gmax){
    for (let i=0; i<4; i++) {
        if (som[i]>max) {
            max = som[i];
            gmax = i;
        }
    }
    return gmax;
}

function maxtot(punt, gmax, maxp) {
    for (let i=0; i<4; i++) {
        if (punt[gmax][i] > maxp) {
            maxp = punt[gmax][i];
        }
    }
    return maxp;
}

