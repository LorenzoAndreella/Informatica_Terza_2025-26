let i=0;
let num1=0;
let num=0;
let soluzione="";
let o=0;
let cr="Cronologia";

function calcolo(i) {

    switch (i) {
        case "0": 
        soluzione = soluzione+"0";
        num=num+"0";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "1":
        soluzione = soluzione+"1";
        num=num+"1";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "2":
        soluzione = soluzione+"2";
        num=num+"2";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "3":
        soluzione = soluzione+"3";
        num=num+"3";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "4":
        soluzione = soluzione+"4";
        num=num+"4";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "5":
        soluzione = soluzione+"5";
        num=num+"5";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "6":
        soluzione = soluzione+"6";
        num=num+"6";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "7":
        soluzione = soluzione+"7";
        num=num+"7";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "8":
        soluzione = soluzione+"8";
        num=num+"8";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "9":
        soluzione = soluzione+"9";
        num=num+"9";
        document.getElementById("risposta").innerText = soluzione;
        break;

        case "+":
           num1=num;
           num=0;
           o="+"
           soluzione = soluzione + " + ";
           document.getElementById("risposta").innerText = soluzione;
           break;

        case "-":
           num1=num;
           num=0;
           o="-"
           soluzione = soluzione + " - ";
           document.getElementById("risposta").innerText = soluzione;
           break;

        case "*":
           num1=num;
           num=0;
           o="*"
           soluzione = soluzione + " x ";
           document.getElementById("risposta").innerText = soluzione;
           break;

        case "/":
           num1=num;
           num=0;
           o="/"
           soluzione = soluzione + " / ";
           document.getElementById("risposta").innerText = soluzione;
           break;

        case "√":
           num1=num;
           num=0;
           o="√"
           soluzione = soluzione + "√";
           document.getElementById("risposta").innerText = soluzione;
           break;

        case "^":
           num1=num;
           num=0;
           o="^"
           soluzione = soluzione + "^";
           document.getElementById("risposta").innerText = soluzione;
           break;
           
        case "C": 
                num="";
                num1="";
                soluzione="";
                document.getElementById("risposta").innerText = "Calcoli:";
                o=0;
            break;

        case "=":
            switch(o) {
            case "+": 
                num=parseFloat(num);
                num1=parseFloat(num1);
                num1=num1+num;
                soluzione=num1;
                document.getElementById("risposta").innerText = num1;
                document.getElementById("cronologia").innerHTML += "<br>" + num1;
                num=num1;
                o=0;
            break;

            case "-": 
                num=parseFloat(num);
                num1=parseFloat(num1);
                num1=num1-num;
                soluzione=num1;
                document.getElementById("risposta").innerText = num1;
                document.getElementById("cronologia").innerHTML += "<br>" + num1;
                num=num1;
                o=0;
                break;

            case "*": 
                num=parseFloat(num);
                num1=parseFloat(num1);
                num1=num1*num;
                soluzione=num1;
                document.getElementById("risposta").innerText = num1;
                document.getElementById("cronologia").innerHTML += "<br>" + num1;
                num=num1;
                o=0;
                break;

            case "/": 
                num=parseFloat(num);
                num1=parseFloat(num1);
                if (num == 0) {
                    document.getElementById("risposta").innerText = "Errore";
                    num="";
                    num1="";
                    soluzione="";
                    o=0;
                } else {
                num1=num1/num;
                soluzione=num1;
                document.getElementById("risposta").innerText = num1;
                document.getElementById("cronologia").innerHTML += "<br>" + num1;
                num=num1;
                o=0;
                }
                break;
            case "√": 
                num=parseFloat(num);
                num1=parseFloat(num1);
                num1=Math.sqrt(num1);
                soluzione=num1;
                document.getElementById("risposta").innerText = num1;
                document.getElementById("cronologia").innerHTML += "<br>" + num1;
                num=num1;
                o=0;
                break;

            case "^": 
                num=parseFloat(num);
                num1=parseFloat(num1);
                num1=num1**num;
                soluzione=num1;
                document.getElementById("risposta").innerText = num1;
                document.getElementById("cronologia").innerHTML += "<br>" + num1;
                num=num1;
                o=0;
                break;

            
        }
        break;

    } 
    }
