function controllo(q) {
    let formm = document.getElementById('formm');
    q = parseInt(q);

    document.getElementById("q").disabled = true;
    document.getElementById("invia").disabled = true;

    if (isNaN(q) || q <1 || q>1000) {
        let p = document.createElement("p");
        formm.appendChild(p);
        p.textContent = "Errore inserisci un valore valido";
        document.getElementById("q").disabled = false;
        document.getElementById("q").value = "";
        document.getElementById("invia").disabled = false;    
        return;
    }
    let input;
    for (let i=0; i<q; i++) {
        formm.appendChild(document.createElement("br"));
        input = document.createElement("input");
        input.id = "inp" + i;
        input.placeholder = "Inserisci numero";
        input.type = "number";
        formm.appendChild(input);
    }
    formm.appendChild(document.createElement("br"));
    let bottone = document.createElement("button");
    bottone.id = "arr";
    bottone.type = "button";
    bottone.textContent = "INVIA"
    formm.appendChild(bottone);
    bottone.onclick = () => conta(q, formm);
    
}

function conta(q, formm) {
    let somma = 0;
    let media = 0;
    for (let i=0; i<q; i++) {
        let n = parseInt(document.getElementById("inp"+i).value);
        if (isNaN(n) || n < -1000 || n> 1000) {
        let p = document.createElement("p");
        formm.appendChild(p);
        p.textContent = "Errore inserisci un valore valido";
        document.getElementById("inp"+i).value = "";
        somma = 0;
        media = 0;
        return;
        } else {
            somma += parseInt(document.getElementById("inp"+i).value);
        }

    }
    media = somma/q;
    let risp = document.createElement('p');
    risp.innerHTML = "La somma è: " + somma + "<br> La media è: " +media;
    formm.appendChild(risp);

}