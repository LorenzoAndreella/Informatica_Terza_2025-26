let turni = new Map([   // creazione mappa turni
    ["08:00-09:00", []],
    ["09:00-10:00", []],
    ["10:00-11:00", []]
]);

function contaStudentiTotali() {
    let totale = 0;
    for (let studenti of turni.values()) {
        totale += studenti.length;
    }
    return totale;
}

function stampaTurni() { // stampa turni e studenti
    let out = "Turni:<br>";
    for (let [ora, studenti] of turni) {
        if (studenti.length > 0) {
            out += "Turno " + ora + ": " + studenti.join(", ") + "<br>";
        } else {
            out += "Turno " + ora + ": Nessuno<br>";
        }
    }
    out += "<br>Numero turni: " + turni.size + "<br>";
    out += "Numero totale studenti: " + contaStudentiTotali() + "<br>";
    out += maxStud();

    document.getElementById("risp").innerHTML += out;
}

function aggiunta(stud, turno) {
    let risp = document.getElementById("risp");
    risp.innerHTML = "";
    if (!stud || turno == "" || turno == "errore") {
        risp.innerHTML += "Inserisci studente e turno<br>";
        stampaTurni();
        return;
    }

    for (let studenti of turni.values()) {
        if (studenti.includes(stud)) {
            risp.innerHTML += "Errore: studente già presente in un turno<br>";
            stampaTurni();
            return;
        }
    }

    turni.get(turno).push(stud);
    risp.innerHTML += "Studente aggiunto correttamente<br>";
    stampaTurni();
}

function cerca(stud) {
    for (let [ora, studenti] of turni) {
        if (studenti.includes(stud)) {
            return ora;
        }
    }
    return null;
}

function ricercaStudent() {
    let risp = document.getElementById("risp");
    risp.innerHTML = "";
    let stud = document.getElementById("cerc").value;

    if (!stud) {
        risp.innerHTML += "Inserisci uno studente da cercare<br>";
        stampaTurni();
        return;
    }

    let turnoTrovato = cerca(stud);
    if (turnoTrovato) {
        risp.innerHTML += "Studente " + stud + " prenotato nel turno " + turnoTrovato + "<br>";
    } else {
        risp.innerHTML += "Studente " + stud + " non presente in nessun turno<br>";
    }
    stampaTurni();
}

function rim(stud, turno) {
    let risp = document.getElementById("risp");
    risp.innerHTML = "";

    if (!stud || !turno) {          //controllo input
        risp.innerHTML += "Inserisci studente e turno<br>";
        stampaTurni();
        return;
    }

    let studenti = turni.get(turno);    //ottengo array studenti del turno
    if (!studenti) { //controllo turno valido
        risp.innerHTML += "Turno non valido<br>";
        stampaTurni();
        return;
    }

    let index = studenti.indexOf(stud);
    if (index == -1) { //indexOf restituisce -1 se non trova l'elemento
        risp.innerHTML += "Studente non trovato nel turno<br>";
        stampaTurni();
        return;
    }

    studenti.splice(index, 1);      //rimuvo studente dall'array
    risp.innerHTML += "Studente rimosso correttamente<br>";
    stampaTurni();
}

function minStud(min) {
    let risp = document.getElementById("risp");
    risp.innerHTML = "";

    min = parseInt(min);    
    if (!min || min < 1) {      //controllo input
        risp.innerHTML += "Inserisci un numero valido di studenti<br>";
        stampaTurni();
        return;
    }

    let out = "Turni con almeno " + min + " studenti:<br>";
    let trovato = false;

    for (let [ora, studenti] of turni) {
        if (studenti.length >= min) {       //controllo se il numero studenti è almeno min
            out += "Turno " + ora + ": " + studenti.join(", ") + "<br>"; //stampa turno (array)
            trovato = true;     //trovato almeno un turno
        }
    }

    if (!trovato) {       //non sono stati trovati turni con almeno min studenti 
        out += "Nessun turno trovato con almeno " + min + " studenti.<br>";
    }

    risp.innerHTML += out;      //stampa risultati
    stampaTurni();

}

function maxStud() {
    let max = 0;        //inizializzo max a 0
    for (let studenti of turni.values()) {
        if (studenti.length > max) {
            max = studenti.length;      //aggiorno il max
        }
    }

    let out = "Turni con il massimo numero di studenti (" + max + "):<br>";
    if (max == 0) {
        out += "Nessuno studente iscritto in nessun turno<br>";
    } else {
        for (let [ora, studenti] of turni) {
            if (studenti.length == max) {
                out +=  ora + "<br>";       //stampa i turni con max studenti
            }
        }
    }

    return out; //ritorno la stringa da stampare nella funzione stampaTurni
}