let arr = [];

function stop() { //dopo aver inserito tutti i numeri
    let pa = 0;
    let pr = 1;
    document.getElementById('invia').disabled = true;
    for (let i of arr) {
        if(i%2 == 0) {  //sommo numeri pari
            pa += i;
        }
    }

    for (let i in arr) {
        if(i%2 == 1) {      //moltiplico numeri in posizione dispari
            pr *= arr[i];
        }
    }
    console.log(pa, pr);
    document.getElementById('risp').innerHTML = "La somma dei numeri pari: " + pa + "<br> Prodotto degli elementi in posizione dispari: " +pr;
}

function controllo(numero) { //controllo numero per numero
    n = parseInt(numero);
    console.log(n);
    if(isNaN(n)) {
        document.getElementById('risp').textContent = "Errore, inserisci numeri";

    } else {
        arr.push(n); //array 
        console.log(arr);
    }
    document.getElementById('n').value = ""; //svuoto l'input
    return;
}
