function terna() {
    let soluzione;
    let t =0;
    let a;
    let b;
    let c = 3;
    
    for (a = 1; a <= 100; a++) {
        for (b = a + 1; b <= 100; b++) {
            for (c = b + 1; c <= 100; c++) {
                if (a*a + b*b == c*c) {
                    t = t + 1;
                }
            }
        }
    }
    soluzione = "Le terne pitagoriche tali che 1<=a<b<c<=100 sono " + t;
    document.getElementById("risposta").innerText = soluzione;
} 
