function amici() {
    let n = parseInt(document.getElementById("num").value);
    let n1 = parseInt(document.getElementById("num1").value);
    let s = 0;
    let s1 = 0;
    let i;
    let soluzione;

    if (n < 0 || n1 < 0 || isNaN(n) || isNaN(n1) || n > 9999999999 || n1 > 9999999999) {
        soluzione = "Inserisci valori validi";
    } else {
        for (i = n - 1; i >= 1; i--) {
            if (n % i == 0) {
                s = s + i;
            }
        }
        for (i = n1 - 1; i >= 1; i--) {
            if (n1 % i == 0) {
                s1 = s1 + i;
            }
        }
        if (s == n1 && s1 == n && s != 0) {
            soluzione = "Numeri amici";
        } else {
            soluzione = "Numeri non amici";
        }
    }

    document.getElementById("risposta").innerText = soluzione;
}
