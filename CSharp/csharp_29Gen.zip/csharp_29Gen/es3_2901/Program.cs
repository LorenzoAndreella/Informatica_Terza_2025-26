﻿using System;

public class Program
{
        public static void Main(string[] args)
    {
        int n1, n2, MCD;

        Console.WriteLine("Inserisci il numero di pezzi del primo ordine:");
        bool x = int.TryParse(Console.ReadLine(), out n1);
        while (!x || n1<0 || n1> 99999)
        {
            Console.WriteLine("Inserisci il numero di pezzi corretto del primo ordine:");
            x = int.TryParse(Console.ReadLine(), out n1);
        }

        Console.WriteLine("Inserisci il numero di pezzi del secondo ordine:");
            x = int.TryParse(Console.ReadLine(), out n2);
        while (!x || n2<0 || n2> 99999)
        {
            Console.WriteLine("Inserisci il numero di pezzi corretto del secondo ordine:");
            x = int.TryParse(Console.ReadLine(), out n2);
        }

        while (n2 != 0)
    {
        int temp = n2;
        n2 = n1 % n2;
        n1 = temp;
    }
    MCD = n1;
    Console.WriteLine($"MCD dei due numeri (gruppi): {MCD}");
    }
}
