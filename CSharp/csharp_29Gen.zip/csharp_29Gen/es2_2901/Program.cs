﻿using System;


public class Program
{
    public static void Main(string[] args)
    {
        int d, n, ind;
        Console.WriteLine("Scegli la difficoltà: 1Facile, 2Media e 3Difficile");
        bool x = int.TryParse(Console.ReadLine(), out d);
        while ((d!=1 && d!=2 && d!=3) || !x)
        {
            Console.WriteLine("Errore. Scegli la difficoltà: 1Facile, 2Media e 3Difficile");
            x = int.TryParse(Console.ReadLine(), out d);
        }
        Random rnd = new();
        n = 0;
        switch(d)
        {
            case 1:
            n = rnd.Next(1,6);
            break;
            case 2:
            n = rnd.Next(1,11);
            break;
            case 3:
            n = rnd.Next(1,20);
            break;
            default:
            break;
        }

        for (int i=0; i<3; i++)
        { 
            do
            {
                Console.WriteLine("Inodovina il numero: ");
                x = int.TryParse(Console.ReadLine(), out ind);
            } while(!x);
            if (ind<n)
            {
                Console.WriteLine("Il numero è più alto");
                Console.WriteLine("Hai ancora " + (2-i) + " tentativi");
            }
            else if (ind>n)
            {
                Console.WriteLine("Il numero è più basso");
                Console.WriteLine("Hai ancora " + (2-i) + " tentativi");
            }
            else
            {
                Console.WriteLine("Hai indovinato!");
                return;
            
            }
        }
        Console.WriteLine("GAME OVER. Hai esaurito i tentativi. Il numero era " + n);  
    }
}
