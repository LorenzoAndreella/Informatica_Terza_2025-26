﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        int euro = 0;
        int m;
        int i=0;
        while (euro < 500)
        {
            Console.WriteLine("Inserisci il valore della moneta in centesimi");
            bool x = int.TryParse(Console.ReadLine(), out m);
            while (!x || (m!= 1 && m!= 2 && m!=5 && m!=10 && m!=20 && m!=50 && m!=100 && m != 200)) {
                Console.WriteLine("Scrivi una moneta valida");
                x = int.TryParse(Console.ReadLine(), out m);
            }
            euro += m;
            i++;
        }
        Console.WriteLine($"Ora ha abbastanza soldi per la colazione(+5euro) e hai raccolto {i} monete!");
    }
}