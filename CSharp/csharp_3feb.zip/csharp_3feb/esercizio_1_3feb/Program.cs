﻿using System;
using static System.Console;
internal class CodiceSegreto
{
    public static void Main(string[] args)
    {
        int n;
        bool x;
     do
        {
            WriteLine("Inserisci un numero: ");
            x = int.TryParse(ReadLine(), out n);
        } while (!x || n<0);

    int lung = Lunghezza(n);
    int somma = SommaCifre(n, lung);
    int prodotto = ProdottoCifre(n, lung);

    if (somma%3 == 0 && prodotto % 2 == 0)          //controllo che la somma delle cifre sia multiplo di 3 e il loro prodotto pari
        {
            WriteLine("Il codice è valido!");
        }
        else
        {
            WriteLine("Il codice non è valido!");
        }
        
    }

    static int Lunghezza(int n)             //si poteva altrimenti trasformare in stringa e usare .Length
    {
        int lung = 0;

        if (n == 0)
            lung = 1;
        else
        {
            while (n > 0)
            {
                lung++;
                n /= 10;            //sfrutto il fatto che è di tipo intero
            }
        }
        return lung;
    }

    static int SommaCifre(int n, int l)
    {
        int somma = 0;
        for (int i=0; i<l; i++)
        {
            int cifra = n%10;                   //sommo le cifre matematicamente senza vettori
            somma += cifra;
            n /= 10;
        }
        return somma;
    }

    static int ProdottoCifre(int n, int l)
    {
        int prod = 1;
        for (int i=0; i<l; i++)
        {
            int cifra = n%10;                  
            prod *= cifra;
            n /= 10;
        }
        return prod;
    }

  
}

        
