﻿using static System.Console;

internal class ParolaMagica
{
    public static void Main(string[] args)
    {
        WriteLine("Scrivi una parola: ");
        string par = ReadLine();

        bool valido = ControlloVocali(par);

        if (valido)
        {
            WriteLine("Parola valida!");
        }
        else
        {
            WriteLine("La parola contiene meno di 4 vocali diverse");
        }
    }

    static bool ControlloVocali(string par)
    {
        string vocali = "aeiou";                //stringa riferimento vocali

        for (int i = 0; i < par.Length; i++)        //controlla la stringa
        {
            char c = par[i];        //trova

            if (vocali.Contains(c))                 //controlla se è gia stata letta
            {
                int index = vocali.IndexOf(c);          //capisco dove eliminare la vocale
                vocali = vocali.Remove(index, 1);       //rimuovo
            }
        }
        if (vocali.Length <= 1)     //più di 4 vocali scritte
        {
            return true;
        }
        return false;
    }
}