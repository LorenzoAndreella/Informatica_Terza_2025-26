﻿using System;
internal class PiramideDiNumeri
{
    public static void Main(string[] args)
    {
      int n;
      Console.WriteLine("Inserisci un numero per creare una piramide: ");
      bool x = int.TryParse(Console.ReadLine(), out n);
      while (!x || n<=0)                    //controllo che sia un numero valido
        {
            Console.WriteLine("Errore, scrivi un numero valido");
            x = int.TryParse(Console.ReadLine(), out n);
        }
        for (int i=1; i<=n; i++)            //righe della piramide
        {

            for (int k=1; k<=n-i; k++)
                {
                    Console.Write(" ");         //creare la piramide centrata
                }
            
            for(int j=1; j<=i; j++)         //stampa dei numeri crescenti fino a quel numero
            {
                Console.Write(j);
            }
            for(int j=i -1 ; j>0 ; j--)     //stampa dei numeri in maniera decrescente
            {
                Console.Write(j);
            }
            Console.WriteLine("");          //andare a capo
        }
    }

}

        
