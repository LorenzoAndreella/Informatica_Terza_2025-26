﻿using static System.Console;
internal class PercorsoRobot
{
    public static void Main(string[] args)
    {
        int n;
        bool x;
     do
        {
            WriteLine("Inserisci un numero: ");
            x = int.TryParse(ReadLine(), out n);
        } while (!x || n<10);                       //numero con due cifre almeno


        bool sicura = Sicurezza(n);
        if (sicura)
        {
            Write("La strada è sicura");
        } else
        {
            Write("La strada non è sicura");
        }
    }
    
    static bool Sicurezza(int n)
    {
        string num = n.ToString();                  //trasformo in stringa per poter accedere ad ogni posizione
        int lung = num.Length;
        int cifra = int.Parse(num[0].ToString());               //mi serve per capire il primo andamento
        int cifra1 = int.Parse(num[1].ToString());
        bool cres;
        if (cifra > cifra1)
        {
            cres = false;
        } else if(cifra <cifra1)
        {
            cres = true;
        } else
        {
            return false;               //sono uguali
        }

        if (lung < 2)               //apposto perchè ho già fatto il controllo per due
        {
            return true;
        }
        
        for (int i = 1; i < lung - 1; i++)
        {
            cifra = int.Parse(num[i].ToString());                   //prendo i due valori successivi
            cifra1 = int.Parse(num[i + 1].ToString());

            if (cres && cifra > cifra1)
            {
                // cambio da crescente a decrescente
                cres = false;                                   //ora cerco l'altro senso
            }
            else if (!cres && cifra < cifra1)
            {
                //se decrescente torna a crescere la strada non è sicura
                return false;
            }
            //altrimenti la direzione rimane uguale
        }
        return true;                //superati i controlli
    }
}

        
