﻿using System;
using static System.Console;

namespace PrenotazioneCinema
{    
enum TipoBiglietto          //enum per i tipi di biglietto
{
    Standard,
    Ridotto,
    Vip
}

enum StatoPrenotazione          //enum per lo stato della prenotazione
{
    Prenotato,
    Pagato,
    Annullato
}

struct Biglietto            //struct per rappresentare un biglietto
{
    public int NumeroPosto;
    public TipoBiglietto Tipo;
    public StatoPrenotazione Stato;
    public DateTime Data;

    public Biglietto(int posto, TipoBiglietto tipo)
    {
        NumeroPosto = posto;
        Tipo = tipo;                    
        Stato = StatoPrenotazione.Prenotato;                        //lo stato iniziale è sempre prenotato
        Data = DateTime.Now;                                        //la data è quella attuale al momento della creazione del biglietto
    }

    public string Stampa()
    {
        return $"\nPosto: {NumeroPosto}\nTipo: {Tipo}\nStato: {Stato}\nData: {Data.ToShortDateString()}";          //metodo per stampare le informazioni del biglietto (/n per andare a capo), ToShortDateString() per stampare solo la data senza l'ora
    
    }
    public void CambiaStato(StatoPrenotazione nuovoStato)
    {
        Stato = nuovoStato;
    }
}

class Program
{
    static List<Biglietto> biglietti = new List<Biglietto>();           //lista per contenere tutti i biglietti
    public static bool valido;              //variabile globale per il controllo
    static void Main()
    {
        int scelta;
        
        do
        {
            do
            {
                WriteLine("\nGESTIONE PRENOTAZIONI BIGLIETTI");
                WriteLine("1. Crea biglietto");
                WriteLine("2. Paga biglietto");
                WriteLine("3. Annulla biglietto");
                WriteLine("4. Visualizza biglietti");
                WriteLine("5. Esci");
                valido = int.TryParse(ReadLine(), out scelta); 
                if (!valido || scelta < 1 || scelta > 5)             //controllo input
                {
                    WriteLine("Inserisci un numero da 1 a 5");
                }  
            } while (!valido || scelta < 1 || scelta > 5);
            
            switch (scelta)             //esegue l'azione scelta dall'utente
            {
                case 1:
                    CreaBiglietto();
                    break;
                case 2:
                    PagaBiglietto();
                    break;
                case 3:
                    AnnullaBiglietto();
                    break;
                case 4:
                    VisualizzaBiglietti();
                    break;
            }

        } while (scelta != 5);        //continua finché l'utente non sceglie 5
    }

    static void CreaBiglietto()
    {
        int posto;

        do
        {
            do
            {
                Write("Numero di posto: ");
                valido = int.TryParse(ReadLine(), out posto);
                if (!valido || posto < 0)
                {
                    WriteLine("Numero non valido, riprova!");        //verifica che sia un intero positivo
                }

            } while (!valido || posto < 0);
           
            bool occupato = false;
            foreach (var b in biglietti)                       //controlla se il posto è già occupato da un biglietto non annullato
            {
                if (b.NumeroPosto == posto && b.Stato != StatoPrenotazione.Annullato)
                {
                    WriteLine("Posto già occupato!");         
                    occupato = true;
                    break;
                }
            }

            if (occupato)
            {
                valido = false;
            }  

        } while (!valido);

        // Input tipo biglietto
        int tipoScelto;
        do
        {
            WriteLine("Tipo biglietto:");
            WriteLine("0. Standard");
            WriteLine("1. Ridotto");
            WriteLine("2. Vip");
            valido = int.TryParse(ReadLine(), out tipoScelto);

            if (!valido || tipoScelto < 0 || tipoScelto > 2)
            {
                WriteLine("Tipo non valido, riprova!");
            }

        } while (!valido || tipoScelto < 0 || tipoScelto > 2);

        Biglietto nuovo = new Biglietto(posto, (TipoBiglietto)tipoScelto);
   
        bool sostituito = false;            // Controlla se esiste un biglietto annullato con lo stesso posto e lo sovrascrive
        for (int i = 0; i < biglietti.Count; i++)
        {
            if (biglietti[i].NumeroPosto == posto && biglietti[i].Stato == StatoPrenotazione.Annullato)
            {
                biglietti[i] = nuovo;
                sostituito = true;
                break;
            }
        }

        if (!sostituito)
        {
            biglietti.Add(nuovo);  // aggiunge il biglietto solo se non era già annullato
        }

        WriteLine("Biglietto prenotato!");
    }

    static void PagaBiglietto()
    {
        if (biglietti.Count == 0)                   //controllo se ci sono biglietti nella lista
        {
            WriteLine("Nessun biglietto creato");
            return;
        }

        int posto;

        do
        {
            Write("Inserisci numero di posto da pagare: ");
            valido = int.TryParse(ReadLine(), out posto);
            if (!valido || posto < 0)
            {
                WriteLine("Numero non valido");        //controllo input valido  
            }
                
        } while (!valido);

        for (int i = 0; i < biglietti.Count; i++)                       //scorre la lista per trovare il biglietto con il numero di posto inserito dall'utente
        {
            if (biglietti[i].NumeroPosto == posto)
            {
                if (biglietti[i].Stato == StatoPrenotazione.Pagato)
                {
                    WriteLine("Biglietto già pagato!");              //controllo se il biglietto è già pagato
        
                } else if (biglietti[i].Stato == StatoPrenotazione.Annullato)
                {
                    WriteLine("Biglietto annullato, non può essere pagato!");   //controllo se il biglietto è annullato
                    return;
                }

                Biglietto b = biglietti[i];
                b.CambiaStato(StatoPrenotazione.Pagato);                                         //modifica lo stato a pagato
                biglietti[i] = b;                                 //aggiorna la lista (struct non è un riferimento, quindi bisogna aggiornare la lista)
                WriteLine("Biglietto pagato!");
                return;
            }
        }
        WriteLine("Biglietto non trovato");          //se non trova il numero di posto
    }

    static void AnnullaBiglietto()
    {
        if (biglietti.Count == 0)       //controllo lista vuota
        {
            WriteLine("Nessun biglietto creato");
            return;
        }

        int posto;

        do
        {
            Write("Inserisci numero di posto da annullare: ");
            valido = int.TryParse(ReadLine(), out posto);
            if (!valido || posto < 0)
                WriteLine("Numero non valido, riprova!");      //controllo input
        } while (!valido);

        for (int i = 0; i < biglietti.Count; i++)
        {
            if (biglietti[i].NumeroPosto == posto)
            {
                if (biglietti[i].Stato == StatoPrenotazione.Annullato)          //controllo se il biglietto è già annullato
                {
                    WriteLine("Biglietto già annullato!");
                    return;
                }

                Biglietto b = biglietti[i];
                b.CambiaStato(StatoPrenotazione.Annullato);                  //modifica lo stato a annullato
                biglietti[i] = b;             //aggiorna la lista
                WriteLine("Biglietto annullato!");
                return;
            }
        }
        WriteLine("Biglietto non trovato");         //se non trova il numero di posto
    }
    static void VisualizzaBiglietti()
    {
        if (biglietti.Count == 0)           //lista vuota
        {
            WriteLine("Nessun biglietto da visualizzare");
            return;
        }

        foreach (var b in biglietti)        //stampa tutti i biglietti
        {
            WriteLine(b.Stampa());
        }
    }
}
}