﻿using System;
using static System.Console;

namespace AllenamentoMostri {
    enum TipoMostro {
        Fuoco,
        Acqua,
        Erba,
        Elettrico,
        Roccia
    }

    enum LivelloEnergia
    {
        Basso,
        Medio,
        Alto
    }

    struct MostroDigitale
    {
        public int codice;
        public TipoMostro tipo;
        public LivelloEnergia energia;
        public int eta;
        public int forza;
        public string allenatore;

        public MostroDigitale(int codice, TipoMostro tipo, LivelloEnergia energia, int eta, int forza, string allenatore)
        {
            this.codice = codice;
            this.tipo = tipo;
            this.energia = energia;
            this.eta = eta;
            this.forza = forza;
            this.allenatore = allenatore;
        }

        public bool EAllenabile()
        {
            if (energia != LivelloEnergia.Basso)
            {
                return true;
            }
            return false;
        }

        public void CambiaAllenatore(string nuovoAllenatore)
        {
            if (nuovoAllenatore == "")
            {
                allenatore = "Nessuno";
            }else
            {
                allenatore = nuovoAllenatore;
            }
            return;
        }

        public void Allenati(int punti)
        {
            if (EAllenabile())
            {
                if (forza+punti <= 100)
                {
                    forza=forza+punti;
                }
                else
                {
                    forza= 100;
                }
            }
            return;
        }

        public string Descrizione()
        {
            return $"Codice: {codice}, Tipo: {tipo}, Energia: {energia}, Età: {eta}, Forza: {forza}, Allenatore: {allenatore}";
        }
    }

    class Program
    {
        static MostroDigitale[] Centro = new MostroDigitale[5]; //vettore 
        static bool x;      //variabile di controllo
        static int scelta;

        static void Main()
        {
            do
            {
                do
                {
                    WriteLine("\nCentro allenamento mostri");
                    WriteLine("1. Inizializza centro");
                    WriteLine("2. Allena un mostro (per codice)");
                    WriteLine("3. Cambia allenatore per un mostro");
                    WriteLine("4. Scambia allenatore tra due mostri");
                    WriteLine("5. Visualizza tutti i mostri");
                    WriteLine("6. Filtra per tipo di mostro");
                    WriteLine("7. Filtra per livello energia");
                    WriteLine("8. Esci");

                    x = int.TryParse(ReadLine(), out scelta);
                    if (!x)
                    {
                        WriteLine("Inserisci un numero valido");
                    }
                } while (!x);
                switch (scelta)
                {
                    case 1:
                        InizializzaCentro();
                        break;

                    case 2:
                        AllenaUnMostro();
                        break;

                    case 3:
                        CambiaAllenatore();
                        break;

                    case 4:
                        ScambiaAllenatoreTraDue();
                        break;

                    case 5:
                        VisualizzaTutti();
                        break;

                    case 6:
                        FiltraTipo();
                        break;

                    case 7:
                        FiltraEnergia();
                        break;

                    case 8:
                        break;
                    default: 
                        WriteLine("Inserisci un numero tra 1 e 8");
                        break;
                }
            } while (scelta != 8);          //continua in loop
        }

        static void InizializzaCentro()
        {
            for (int i = 0; i < Centro.Length; i++)
            {
                int codice = i;
                TipoMostro tipo = LeggiTipo();
                LivelloEnergia energia = LeggiEnergia();
                int eta = LeggiEta();
                int forza = LeggiForza();
                string allenatore = LeggiAllenatore();

                Centro[i] = new MostroDigitale(codice, tipo, energia, eta, forza, allenatore);          //inserisco nell'array il nuovo mostro
            }

            WriteLine("Inseriti tutti i dinosauri!");
        }

        static void AllenaUnMostro()
        {
            int codice;
            int punti;

            codice = LeggiCodice();
            if (Centro[codice].EAllenabile())           //controllo energia
            {
                do
                {
                    WriteLine("Di quanto vuoi allenare il tuo mostro (punti forza)?");
                    x = int.TryParse(ReadLine(), out punti);
                    if (!x || punti<1 || punti >= 100)
                    {
                        WriteLine("Inserisci un numero valido");
                    }
                } while (!x || punti<1 || punti>=100);
                    
                    Centro[codice].Allenati(punti);
                    WriteLine($"Mostro allenato con successo! Forza: {Centro[codice].forza}");
                    return;
            }else
            {
                WriteLine("Energia troppo bassa");
                return;
            }

        }

        static void CambiaAllenatore()
        {
            scelta = LeggiCodice();
            WriteLine("Scrivi nuovo allenatore");
            Centro[scelta].allenatore = ReadLine();
            return;
        }

        static void ScambiaAllenatoreTraDue()
        {
            scelta = LeggiCodice();
            int scelta1 = LeggiCodice();

            string temp = Centro[scelta].allenatore;
            Centro[scelta].allenatore = Centro[scelta1].allenatore;
            Centro[scelta1].allenatore = temp;
            return;

        }

        static void VisualizzaTutti()
        {
            for (int i = 0; i < Centro.Length; i++)
            {
                WriteLine(Centro[i].Descrizione());
            }
        }

        static void FiltraTipo()
        {
            int trovati = 0;
            WriteLine("Tipo da visualizzare");   
            TipoMostro tipoCercato = LeggiTipo();

            for (int i=0; i<Centro.Length; i++)
            {
                if (Centro[i].tipo == tipoCercato)
                {
                    WriteLine(Centro[i].Descrizione());
                    trovati++;
                }
            }
            WriteLine($"Ci sono {trovati} mostri di tipo {tipoCercato}");
            return;

        }

        static void FiltraEnergia()
        {
            int trovati = 0;
            WriteLine("Energia da visualizzare");   
            LivelloEnergia energiaCercata = LeggiEnergia();

            for (int i=0; i<Centro.Length; i++)
            {
                if (Centro[i].energia == energiaCercata)            //controlla ogni energia
                {
                    WriteLine(Centro[i].Descrizione());
                    trovati++;
                }
            }
            WriteLine($"Ci sono {trovati} mostri con energia {energiaCercata}");
            return;
        }

        /////

        static TipoMostro LeggiTipo()
        {
            do
            {
                WriteLine("\nInserisci un numero");
                WriteLine("0.Fuoco     1.Acqua      2.Erba");
                WriteLine("3.Elettrico     4.Roccia");
                x = int.TryParse(ReadLine(), out scelta);
                if (!x || scelta<0 || scelta > 4)
                {
                    WriteLine("Scrivi un valore valido");
                }
            } while (!x || scelta<0 || scelta>4);
            
            return (TipoMostro)scelta;

        }

        static LivelloEnergia LeggiEnergia()
        {
            do
            {
                WriteLine("\nInserisci un numero");
                WriteLine("0.Basso     1.Medio      2.Alto");
                x = int.TryParse(ReadLine(), out scelta);
                if (!x || scelta<0 || scelta > 2)
                {
                    WriteLine("Scrivi un valore valido");
                }
            } while (!x || scelta<0 || scelta>2);
            
            return (LivelloEnergia)scelta;
        }

        static int LeggiEta()
        {
            do
            {
                WriteLine("\nInserisci l'età (>0)");
                x = int.TryParse(ReadLine(), out scelta);
                if (!x || scelta<0)
                {
                    WriteLine("Scrivi un valore valido");
                }
            } while (!x || scelta<0);
            
            return scelta;
        }

        static int LeggiForza()
        {
            do
            {
                WriteLine("\nInserisci la forza (1-100)");
                x = int.TryParse(ReadLine(), out scelta);
                if (!x || scelta<1 || scelta>100)
                {
                    WriteLine("Inserisci un valore valido");
                }
            } while (!x || scelta<1 || scelta>100);
            return scelta;
        }

        static string LeggiAllenatore()
        {
            string allenatore;
            WriteLine("\nInserisci proprietario");
            allenatore = ReadLine();
            if (allenatore == "")
            {
                allenatore = "Nessuno";
            }
            return allenatore;
        }
        static int LeggiCodice()
        {
            bool ok;
            int codice;
            do
            {
                WriteLine("Inserisci il codice mostro (0-4)");
                ok = int.TryParse(ReadLine(), out codice);
                if (!ok || codice <0 || codice >= Centro.Length)
                {
                    WriteLine("Inserici un codice valido ");
                }
                    
            } while (!ok || codice <0 || codice >= Centro.Length);
            return codice;
        }
    }

}